package com.leekaisheng.minesweeper;

public class Main {
	 public static void main(String[] args) {
	        MineSweeperGame minesweeper = new MineSweeperGame();
	        minesweeper.play();
	    }
}
